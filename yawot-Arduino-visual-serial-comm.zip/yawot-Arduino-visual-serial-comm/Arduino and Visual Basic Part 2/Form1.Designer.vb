﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.comPort_ComboBox = New System.Windows.Forms.ComboBox()
        Me.COMport_LBL = New System.Windows.Forms.Label()
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.clear_BTN = New System.Windows.Forms.Button()
        Me.connect_BTN = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer_LBL = New System.Windows.Forms.Label()
        Me.ButtonSwitch_lbl = New System.Windows.Forms.Label()
        Me.buttonSwitchValue_lbl = New System.Windows.Forms.Label()
        Me.temperature_lbl = New System.Windows.Forms.Label()
        Me.temperatureValue_lbl = New System.Windows.Forms.Label()
        Me.potentiometer_lbl = New System.Windows.Forms.Label()
        Me.potentiometerValue_lbl = New System.Windows.Forms.Label()
        Me.count_lbl = New System.Windows.Forms.Label()
        Me.commandCountVal_lbl = New System.Windows.Forms.Label()
        Me.TimerSpeed_lbl = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'comPort_ComboBox
        '
        Me.comPort_ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comPort_ComboBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.comPort_ComboBox.FormattingEnabled = True
        Me.comPort_ComboBox.Location = New System.Drawing.Point(18, 38)
        Me.comPort_ComboBox.Name = "comPort_ComboBox"
        Me.comPort_ComboBox.Size = New System.Drawing.Size(121, 28)
        Me.comPort_ComboBox.TabIndex = 26
        '
        'COMport_LBL
        '
        Me.COMport_LBL.AutoSize = True
        Me.COMport_LBL.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.COMport_LBL.Location = New System.Drawing.Point(18, 15)
        Me.COMport_LBL.Name = "COMport_LBL"
        Me.COMport_LBL.Size = New System.Drawing.Size(78, 20)
        Me.COMport_LBL.TabIndex = 25
        Me.COMport_LBL.Text = "COM Port"
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox1.HideSelection = False
        Me.RichTextBox1.Location = New System.Drawing.Point(278, 38)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(181, 309)
        Me.RichTextBox1.TabIndex = 30
        Me.RichTextBox1.Text = ""
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(340, 11)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(56, 20)
        Me.Label1.TabIndex = 29
        Me.Label1.Text = "INPUT"
        '
        'clear_BTN
        '
        Me.clear_BTN.Location = New System.Drawing.Point(331, 357)
        Me.clear_BTN.Name = "clear_BTN"
        Me.clear_BTN.Size = New System.Drawing.Size(75, 23)
        Me.clear_BTN.TabIndex = 28
        Me.clear_BTN.Text = "CLEAR"
        Me.clear_BTN.UseVisualStyleBackColor = True
        '
        'connect_BTN
        '
        Me.connect_BTN.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.connect_BTN.Location = New System.Drawing.Point(150, 38)
        Me.connect_BTN.Name = "connect_BTN"
        Me.connect_BTN.Size = New System.Drawing.Size(102, 32)
        Me.connect_BTN.TabIndex = 27
        Me.connect_BTN.Text = "Connect"
        Me.connect_BTN.UseVisualStyleBackColor = True
        '
        'Timer1
        '
        '
        'Timer_LBL
        '
        Me.Timer_LBL.AutoSize = True
        Me.Timer_LBL.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Timer_LBL.Location = New System.Drawing.Point(18, 84)
        Me.Timer_LBL.Name = "Timer_LBL"
        Me.Timer_LBL.Size = New System.Drawing.Size(88, 20)
        Me.Timer_LBL.TabIndex = 31
        Me.Timer_LBL.Text = "Timer: OFF"
        '
        'ButtonSwitch_lbl
        '
        Me.ButtonSwitch_lbl.AutoSize = True
        Me.ButtonSwitch_lbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonSwitch_lbl.Location = New System.Drawing.Point(18, 178)
        Me.ButtonSwitch_lbl.Name = "ButtonSwitch_lbl"
        Me.ButtonSwitch_lbl.Size = New System.Drawing.Size(112, 20)
        Me.ButtonSwitch_lbl.TabIndex = 32
        Me.ButtonSwitch_lbl.Text = "Button Switch:"
        '
        'buttonSwitchValue_lbl
        '
        Me.buttonSwitchValue_lbl.AutoSize = True
        Me.buttonSwitchValue_lbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.buttonSwitchValue_lbl.Location = New System.Drawing.Point(150, 178)
        Me.buttonSwitchValue_lbl.Name = "buttonSwitchValue_lbl"
        Me.buttonSwitchValue_lbl.Size = New System.Drawing.Size(46, 20)
        Me.buttonSwitchValue_lbl.TabIndex = 33
        Me.buttonSwitchValue_lbl.Text = "value"
        '
        'temperature_lbl
        '
        Me.temperature_lbl.AutoSize = True
        Me.temperature_lbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.temperature_lbl.Location = New System.Drawing.Point(18, 212)
        Me.temperature_lbl.Name = "temperature_lbl"
        Me.temperature_lbl.Size = New System.Drawing.Size(104, 20)
        Me.temperature_lbl.TabIndex = 34
        Me.temperature_lbl.Text = "Temperature:"
        '
        'temperatureValue_lbl
        '
        Me.temperatureValue_lbl.AutoSize = True
        Me.temperatureValue_lbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.temperatureValue_lbl.Location = New System.Drawing.Point(150, 212)
        Me.temperatureValue_lbl.Name = "temperatureValue_lbl"
        Me.temperatureValue_lbl.Size = New System.Drawing.Size(46, 20)
        Me.temperatureValue_lbl.TabIndex = 35
        Me.temperatureValue_lbl.Text = "value"
        '
        'potentiometer_lbl
        '
        Me.potentiometer_lbl.AutoSize = True
        Me.potentiometer_lbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.potentiometer_lbl.Location = New System.Drawing.Point(18, 246)
        Me.potentiometer_lbl.Name = "potentiometer_lbl"
        Me.potentiometer_lbl.Size = New System.Drawing.Size(113, 20)
        Me.potentiometer_lbl.TabIndex = 36
        Me.potentiometer_lbl.Text = "Potentiometer:"
        '
        'potentiometerValue_lbl
        '
        Me.potentiometerValue_lbl.AutoSize = True
        Me.potentiometerValue_lbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.potentiometerValue_lbl.Location = New System.Drawing.Point(150, 246)
        Me.potentiometerValue_lbl.Name = "potentiometerValue_lbl"
        Me.potentiometerValue_lbl.Size = New System.Drawing.Size(46, 20)
        Me.potentiometerValue_lbl.TabIndex = 37
        Me.potentiometerValue_lbl.Text = "value"
        '
        'count_lbl
        '
        Me.count_lbl.AutoSize = True
        Me.count_lbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.count_lbl.Location = New System.Drawing.Point(21, 362)
        Me.count_lbl.Name = "count_lbl"
        Me.count_lbl.Size = New System.Drawing.Size(130, 20)
        Me.count_lbl.TabIndex = 38
        Me.count_lbl.Text = "Command count:"
        '
        'commandCountVal_lbl
        '
        Me.commandCountVal_lbl.AutoSize = True
        Me.commandCountVal_lbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.commandCountVal_lbl.Location = New System.Drawing.Point(150, 362)
        Me.commandCountVal_lbl.Name = "commandCountVal_lbl"
        Me.commandCountVal_lbl.Size = New System.Drawing.Size(18, 20)
        Me.commandCountVal_lbl.TabIndex = 39
        Me.commandCountVal_lbl.Text = "0"
        '
        'TimerSpeed_lbl
        '
        Me.TimerSpeed_lbl.AutoSize = True
        Me.TimerSpeed_lbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TimerSpeed_lbl.Location = New System.Drawing.Point(18, 108)
        Me.TimerSpeed_lbl.Name = "TimerSpeed_lbl"
        Me.TimerSpeed_lbl.Size = New System.Drawing.Size(104, 20)
        Me.TimerSpeed_lbl.TabIndex = 40
        Me.TimerSpeed_lbl.Text = "Timer speed: "
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(492, 405)
        Me.Controls.Add(Me.TimerSpeed_lbl)
        Me.Controls.Add(Me.commandCountVal_lbl)
        Me.Controls.Add(Me.count_lbl)
        Me.Controls.Add(Me.potentiometerValue_lbl)
        Me.Controls.Add(Me.potentiometer_lbl)
        Me.Controls.Add(Me.temperatureValue_lbl)
        Me.Controls.Add(Me.temperature_lbl)
        Me.Controls.Add(Me.buttonSwitchValue_lbl)
        Me.Controls.Add(Me.ButtonSwitch_lbl)
        Me.Controls.Add(Me.comPort_ComboBox)
        Me.Controls.Add(Me.COMport_LBL)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.clear_BTN)
        Me.Controls.Add(Me.connect_BTN)
        Me.Controls.Add(Me.Timer_LBL)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents comPort_ComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents COMport_LBL As System.Windows.Forms.Label
    Friend WithEvents SerialPort1 As System.IO.Ports.SerialPort
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents clear_BTN As System.Windows.Forms.Button
    Friend WithEvents connect_BTN As System.Windows.Forms.Button
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Timer_LBL As System.Windows.Forms.Label
    Friend WithEvents ButtonSwitch_lbl As System.Windows.Forms.Label
    Friend WithEvents buttonSwitchValue_lbl As System.Windows.Forms.Label
    Friend WithEvents temperature_lbl As System.Windows.Forms.Label
    Friend WithEvents temperatureValue_lbl As System.Windows.Forms.Label
    Friend WithEvents potentiometer_lbl As System.Windows.Forms.Label
    Friend WithEvents potentiometerValue_lbl As System.Windows.Forms.Label
    Friend WithEvents count_lbl As System.Windows.Forms.Label
    Friend WithEvents commandCountVal_lbl As System.Windows.Forms.Label
    Friend WithEvents TimerSpeed_lbl As System.Windows.Forms.Label

End Class
